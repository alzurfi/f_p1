<?php

return [
    '' => [
        'file' => 'home',
        'name' => 'Home',
        'layout' => '',
        'body_class' => '',
    ],
];
