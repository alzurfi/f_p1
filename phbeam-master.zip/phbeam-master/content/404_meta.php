<?php

return [
    'title' => 'Page not found',
    'description' => '',
    'keywords' => '',
];
