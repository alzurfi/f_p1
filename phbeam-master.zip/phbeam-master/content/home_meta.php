<?php

return [
    'title' => 'PHBeam',
    'description' => '',
    'keywords' => '',
];
