<?php echo $GLOBALS['article']; ?>
