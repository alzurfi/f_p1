<!DOCTYPE html>
<html lang="en">
	<head>
		<?php phb_insert_meta_tags(); ?>
	</head>
	<body<?php phb_add_body_class(); ?>>
		<?php phb_insert_page_content(); ?>
	</body>
</html>
