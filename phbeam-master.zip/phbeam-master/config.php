<?php

return [
    'allowed_url_params' => [
        'yclid',
    ],
    'default_body_class' => '',
    'default_layout' => 'bare',
    'error_page_layout' => 'bare',
    'menus' => [
        'main',
    ],
    'modules_classes_prefix' => 'module',
];
